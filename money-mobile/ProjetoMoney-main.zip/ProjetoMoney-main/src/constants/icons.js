import add from "../assets/image/add.png"
import remove from "../assets/image/remove.png"
import logo from "../assets/image/logo.png"
import money from "../assets/image/money.png"

export default { add, remove, logo, money }
