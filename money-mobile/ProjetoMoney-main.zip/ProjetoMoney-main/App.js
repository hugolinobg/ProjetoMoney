import Home from "./src/screens/home/Home"

export default function App() {
  return <Home />
}
